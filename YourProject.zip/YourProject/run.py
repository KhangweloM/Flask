from flask import Flask, render_template

# Initialize Flask application
app = Flask(__name__, template_folder='app/templates', static_folder='app/static')

# Define routes directly in run.py
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/gdp')
def gdp():
    return render_template('gdp_page.html')

@app.route('/inflation')
def inflation():
    return render_template('inflation_page.html')

# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True)
