var chartScript = document.createElement('script');
chartScript.src = 'https://cdn.jsdelivr.net/npm/chart.js';
document.head.appendChild(chartScript);

chartScript.onload = function() {
    var ctx = document.getElementById('gdp-chart').getContext('2d');
    var chart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['2016', '2017', '2018', '2019', '2020'],
            datasets: [{
                label: 'GDP Growth',
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgba(255, 99, 132, 1)',
                data: [2.3, 3.1, 2.9, 2.3, -3.5]
            }]
        },
        options: {
            maintainAspectRatio: false // This makes the chart responsive
        }
    });
};
