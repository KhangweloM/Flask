// Dynamically load Chart.js library
var chartScript = document.createElement('script');
chartScript.src = 'https://cdn.jsdelivr.net/npm/chart.js';
document.head.appendChild(chartScript);

chartScript.onload = function() {
    var ctx = document.getElementById('inflation-chart').getContext('2d');
    var chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['2016', '2017', '2018', '2019', '2020'],
            datasets: [{
                label: 'Inflation Rate',
                backgroundColor: 'rgb(75, 192, 192)',
                borderColor: 'rgb(75, 192, 192)',
                data: [1.26, 2.13, 2.49, 1.81, 1.23]
            }]
        },
        options: {}
    });
};
